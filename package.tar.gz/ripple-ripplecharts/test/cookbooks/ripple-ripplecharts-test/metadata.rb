name 'ripple-ripplecharts-test'
description 'Set up a valid cookbook test environment for ripple-ripplecharts'
