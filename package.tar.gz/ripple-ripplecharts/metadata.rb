name 'ripple-ripplecharts'
description 'Configures the API for Ripple Charts, a charting and reporting system for Ripple'
version '0.0.1'

depends 'application_nodejs'
