default['ripple']['ripplecharts']['api']['app']['port'] = 5993

default['ripple']['ripplecharts']['api']['app']['db']['username'] = 'CHANGEME'
default['ripple']['ripplecharts']['api']['app']['db']['password'] = 'CHANGEME'
default['ripple']['ripplecharts']['api']['app']['db']['host'] = 'localhost'
default['ripple']['ripplecharts']['api']['app']['db']['port'] = 5984
default['ripple']['ripplecharts']['api']['app']['db']['database_name'] = 'CHANGEME'
