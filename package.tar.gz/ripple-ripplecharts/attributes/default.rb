default['nodejs']['version'] = '0.10.25'
